package com.tushar.expenses.periods;

public enum TransactionType {
	EXPENSE, RECEIVED;
}
